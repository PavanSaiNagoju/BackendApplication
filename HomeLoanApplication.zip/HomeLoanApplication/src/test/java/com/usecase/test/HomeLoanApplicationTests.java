package com.usecase.test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.usecase.HomeLoanApplication;


@SpringBootTest(classes = HomeLoanApplication.class)
class HomeLoanApplicationTests {

	@Test
	void contextLoads() {
		
		System.out.println("Testcase-----------");
		
	}

}
