package com.usecase.test.service;

public class UserLogoutTest {

}
